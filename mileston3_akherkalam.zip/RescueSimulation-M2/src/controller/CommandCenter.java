package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.sound.midi.MidiDevice.Info;
import javax.swing.*;
import javax.swing.border.Border;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.CannotTreatException;
import exceptions.CitizenAlreadyDeadException;
import exceptions.IncompatibleTargetException;
import model.disasters.Fire;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import model.units.UnitState;
import simulation.Rescuable;
import simulation.Simulator;


public class CommandCenter extends JFrame implements SOSListener,MouseListener {
	JPanel grid;
	JPanel left;
	JPanel units;
	JPanel unitsResponding;
	JPanel unitsTreating;
	
	JPanel nextCycle;
	JPanel currentCycle;
	JPanel mainPanel,gameOverPanel;
	ImageIcon citizenIcon,citizenIcon0,buildingIcon,buildingIcon0,buildingwzppl,firetruckicon,ambulanceicon,evacuatoricon,diseaseicon,gasicon,deadcitizen,collapsedbuilding;
	 
	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	@SuppressWarnings("unused")
	private ArrayList<Unit> emergencyUnits;
	private JButton[][] gridcells ;
	private ArrayList<JButton> unitsArray;
	private JButton nextCycleButton;
	private JLabel numofcasultion;
	private JLabel currentCycleText,gameOverText;
	private JTextArea logText;
	private JTextArea InfoPanel;
	private ArrayList<JButton>respondingUnit;
	private ArrayList<JButton> TreatingUnit;
    private JLabel log, linfo;
    private JLabel titleofavailableunits;
    private JLabel titleofrespondingunits;
    private JLabel titleoftreatingunits;
    private String games="";
	private JButton ambulanceB;
	private JButton diseaseB;
	private JButton gasB;
	private JButton evacuatorB;
	private JButton fireTruckB;
	private boolean click;
	private Rescuable lastRclicked;
	private int lastUclickedi;
	
	public CommandCenter() throws Exception {
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setTitle("Rescue Simulation");
		engine = new Simulator(this);
		mainPanel = new JPanel();
		gameOverPanel = new JPanel();
		gameOverPanel.setLayout(null);
		gameOverPanel.setBackground(Color.pink);
		gameOverText = new JLabel(games);
		gameOverText.setBounds(600, 45, 200, 10);

		JLabel gameoverimag = new JLabel();
		gameoverimag.setBounds(500, 25, 1200, 600);
		ImageIcon img = new ImageIcon("giphy.gif");
		gameoverimag.setIcon(img);
		gameOverPanel.add(gameoverimag);
		gameOverPanel.add(gameOverText);
		games = "Game Over! \n "+ "Your Score is: "+engine.calculateCasualties();
	    gameOverText.setText(games);
		
		citizenIcon = new ImageIcon("injuredperson.jpg");
		citizenIcon0 = new ImageIcon("citzen0.jpg");
		buildingIcon = new ImageIcon("buildingIcon.jpg");
		buildingIcon0 = new ImageIcon("buldingIcon0.jpg");
		buildingwzppl = new ImageIcon("buldingIcon0.jpg");
		firetruckicon = new ImageIcon("firetruckicon.png");
		ambulanceicon = new ImageIcon("ambulanceicon.png");
		diseaseicon = new ImageIcon("diseaseiconnew.png");
		gasicon = new ImageIcon("gasicon.png");
		evacuatoricon = new ImageIcon("evacuatoricon.png");
		deadcitizen = new ImageIcon("graveicon.png");
		collapsedbuilding= new ImageIcon("collapsedbuilding.png");
		titleofavailableunits=new JLabel("Available Units to use: ");
		titleofavailableunits.setBounds(0,300, 20, 200);
		titleofrespondingunits=new JLabel("Responding Units: ");
		titleofrespondingunits.setBounds(0,300, 20, 200);
		titleoftreatingunits=new JLabel("Treating Units:");
		titleoftreatingunits.setBounds(0,300,20, 200);
		//this.setSize(1000,600);
		mainPanel.setLayout(null);
		mainPanel.setBackground(Color.pink);
		left= new JPanel();
		this.getContentPane().add(mainPanel);
	
		
		nextCycle = new JPanel();
		nextCycle.setLayout(new FlowLayout());
		nextCycle.setBounds(0,0, 300, 40);
		nextCycle.setBackground(Color.PINK);
		nextCycle.setPreferredSize(new Dimension(300,30));
		mainPanel.add(nextCycle);
		// units grid 
		units= new JPanel();
		units.setLayout(new GridLayout(3,2,10,10));
		units.setBounds(0,45,300,220);
		units.setBackground(Color.pink);
		units.add(titleofavailableunits);
		mainPanel.add(units);
		
		unitsResponding= new JPanel();
		unitsResponding.setLayout(new GridLayout(3,2,10,10));
		unitsResponding.setBounds(0,270,300,150);
		unitsResponding.setBackground(Color.pink);
		unitsResponding.add(titleofrespondingunits);
		mainPanel.add(unitsResponding);
		
		unitsTreating= new JPanel();
		unitsTreating.setLayout(new GridLayout(3,2,10,10));
		unitsTreating.setBounds(0,430,300,150);
		unitsTreating.setBackground(Color.pink);
		unitsTreating.add(titleoftreatingunits);
		mainPanel.add(unitsTreating);
		
		grid= new JPanel();
		grid.setBounds(300, 0, 800, 700);
		grid.setBackground(Color.gray);
		grid.setLayout(new GridLayout(10,10,3,3));
		mainPanel.add(grid);
	
		
		currentCycle= new JPanel();
		currentCycle.setBounds(0,590, 300,110);
		currentCycle.setLayout(new GridLayout(2,1,1,1));
		currentCycle.setBackground(Color.pink);
		mainPanel.add(currentCycle);
		unitsArray=new ArrayList<JButton>();
		respondingUnit=new ArrayList<JButton>();
		TreatingUnit= new ArrayList<JButton>();
		nextCycleButton=new JButton("next cycle");
		nextCycleButton.addMouseListener(this);
		InfoPanel=new JTextArea("Press to show info");
		InfoPanel.setBounds(1100,0, 300, 420);
		InfoPanel.setBackground(Color.pink);
		InfoPanel.setForeground(Color.blue);
		logText=new JTextArea("Game Log");
		logText.setBounds(1100, 430, 300, 270);
		logText.setEditable(false);
		logText.setBackground(Color.pink);
		logText.setForeground(Color.RED);
		logText.setLineWrap(true);
		logText.setWrapStyleWord(true);
		numofcasultion=new JLabel("Num of casualities: ");
		currentCycleText=new JLabel("Current cycle: ");
		
		nextCycle.setPreferredSize(new Dimension(300,30));
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		
		
		emergencyUnits = engine.getEmergencyUnits();
		gridcells=new JButton[10][10];
		// bn add buttons to the grid 
		for(int i=0;i<10;i++){
			for (int j = 0; j < 10; j++) {
				JButton b=new JButton();
				b.addMouseListener(this);
				gridcells[i][j] = b;
				getGrid(b);
			}
		}
	
		
		for (int i = 0; i < emergencyUnits.size(); i++) {
			Unit u = emergencyUnits.get(i);
			if (u instanceof Ambulance) {
				ambulanceB =new JButton();
				ambulanceB.addMouseListener(this);
				ambulanceB.setIcon(ambulanceicon);
				getUnits(ambulanceB);
				unitsArray.add(ambulanceB);
			} else if (u instanceof DiseaseControlUnit) {
				diseaseB =new JButton();
				diseaseB.addMouseListener(this);
				diseaseB.setIcon(diseaseicon);
				getUnits(diseaseB);
				unitsArray.add(diseaseB);
			} else if (u instanceof GasControlUnit) {
				gasB =new JButton();
				gasB.addMouseListener(this);
				gasB.setIcon(gasicon);
				getUnits(gasB);
				unitsArray.add(gasB);
			} else if (u instanceof Evacuator) {
				evacuatorB =new JButton();
				evacuatorB.addMouseListener(this);
				evacuatorB.setIcon(evacuatoricon);
				getUnits(evacuatorB);
				unitsArray.add(evacuatorB);
			} else if (u instanceof FireTruck) {
				fireTruckB =new JButton();
				fireTruckB.addMouseListener(this);
				fireTruckB.setIcon(firetruckicon);
				getUnits(fireTruckB);
				unitsArray.add(fireTruckB);
			}
		} 
		
		this.getInfo(InfoPanel);
		getLog(logText);
		getCurrentCycle(numofcasultion);
		getCurrentCycle(currentCycleText);
		getNextCycle(nextCycleButton);
	

		update();
		
		setVisible(true);
		
	}

	private void update() {
		// TODO Auto-generated method stub
		//putUnits();
		putCitizens();
		putBuildings();
	//	updateUnits();
		numofcasultion.setText("Number of casualities: "+this.engine.calculateCasualties());
		currentCycleText.setText("Current Cycle: "+this.engine.getCurrentCycle());
		
        for (int i = 0; i < engine.getEmergencyUnits().size(); i++) {
			Unit u = engine.getEmergencyUnits().get(i);
			if (u.getState() == UnitState.IDLE) {
				unitsTreating.remove(unitsArray.get(i));
				units.add(unitsArray.get(i));
				unitsArray.get(i).setEnabled(true);
			}
			if (u.getState() == UnitState.RESPONDING) {
				units.remove(unitsArray.get(i));
				unitsResponding.add(unitsArray.get(i));
				unitsArray.get(i).setEnabled(false);
			} if (u.getState() == UnitState.TREATING) {
				unitsResponding.remove(unitsArray.get(i));
				unitsTreating.add(unitsArray.get(i));
				unitsArray.get(i).setEnabled(false);
			}
			
		}
		
		printLogInfo();
		this.validate();
		this.repaint();
	}

		

	@Override
	public void receiveSOSCall(Rescuable r) {
		
		if (r instanceof ResidentialBuilding) {
			
			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);
			
		} else {
			
			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}
		
	}
	public void getGrid(JButton b) {
		grid.add(b);
	}
	public JPanel getLeft() {
		return left;
	}
	public void getUnits(JButton b) {
		units.add(b);
	}
	public void getUnitsResponding(JButton b) {
		unitsResponding.add(b);
	}
	public void getUnitsTreating(JButton b) {
		unitsTreating.add(b);
	}
	public void getInfo(JTextArea txt) {
		mainPanel.add(txt);
	}
	public void getNextCycle(JButton b) {
		nextCycle.add(b);
	}
	public void getLog(JTextArea txt) {
		mainPanel.add(txt);
	}
	public void getCurrentCycle(JLabel txt) {
		currentCycle.add(txt);
	}
	

	public void putCitizens(){
		 for (int i = 0; i < engine.getCitizens().size(); i++) {
			 Citizen c=engine.getCitizens().get(i);
			 int x=c.getLocation().getX();
			 int y=c.getLocation().getY();
			 if(c.getState()==CitizenState.SAFE || c.getState()==CitizenState.RESCUED)
			 gridcells[y][x].setIcon(citizenIcon0);
			 if(c.getState()==CitizenState.IN_TROUBLE)
				 gridcells[y][x].setIcon(citizenIcon);
			 if(c.getState()==CitizenState.DECEASED){
				 gridcells[y][x].setIcon(deadcitizen);
				 logText.setText("Citizen:"+c.getName()+"has died"+"at location:"+"("+x+","+y+")");
			 }
		} 
		 /*for(int i=0;i<visibleCitizens.size();i++){
		      Citizen c=visibleCitizens.get(i);
		      int x=c.getLocation().getX();
			  int y=c.getLocation().getY();
			  gridcells[y][x].setIcon(citizenIcon);
	}*/
		 validate();
		 repaint();
		 
}
	public void putBuildings(){
		
		 for (int i = 0; i < engine.getBuildings().size(); i++) {
			 ResidentialBuilding c=engine.getBuildings().get(i);
			 int x=c.getLocation().getX();
			 int y=c.getLocation().getY();
			 if(c.getOccupants().size()==0)
			    gridcells[y][x].setIcon(buildingIcon0);
			 else
				gridcells[y][x].setIcon(buildingwzppl); 
		} 
		 for(int i=0;i<visibleBuildings.size();i++){
			 ResidentialBuilding c=visibleBuildings.get(i);
		      int x=c.getLocation().getX();
			  int y=c.getLocation().getY();
			  gridcells[y][x].setIcon(buildingIcon);
			  if(c.getStructuralIntegrity()==0)
			gridcells[y][x].setIcon(collapsedbuilding);
	}
		 
		 validate();
		 repaint();

	}
	public void printLogInfo(){
		String s= "Executed disasters: "+this.engine.executedDisastersInfo()+"\n Active Disasters: " +this.engine.getActiveDisaster();
		logText.setText("Game Log"+"\n"+s);
		logText.setLineWrap(true);
		logText.setWrapStyleWord(true);
		
		
	}
	public static void main(String[] args) throws Exception{
		new CommandCenter();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
	
		for (int i = 0; i < engine.getBuildings().size(); i++) {
			ResidentialBuilding c = engine.getBuildings().get(i);
			int x = c.getLocation().getX();
			int y = c.getLocation().getY();
			if (e.getSource() == gridcells[y][x]) {
				InfoPanel.setText(c.ResidentialtoString());
				if(click){
					lastRclicked = c;
					try {
						engine.getEmergencyUnits().get(lastUclickedi).respond(c);
					} catch (CannotTreatException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(this, e1.getMessage());
					} catch (IncompatibleTargetException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(this, e1.getMessage());
					}
					click = false;
					lastRclicked = null;
				}
			}
		}	
		
		for (int i = 0; i < engine.getCitizens().size(); i++) {
			Citizen c = engine.getCitizens().get(i);
			int x = c.getLocation().getX();
			int y = c.getLocation().getY();
			if (e.getSource() == gridcells[y][x]) {
				InfoPanel.setText(c.CitizentoString());
				if(click){
					lastRclicked = c;
					try {
						engine.getEmergencyUnits().get(i).respond(c);
					} catch (CannotTreatException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(this, e1.getMessage());
					} catch (IncompatibleTargetException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(this, e1.getMessage());
					}
					click = false;
					lastRclicked = null;
				}
			}
		}
		
	
		
		if (e.getSource() == nextCycleButton) {
			try {
				
				if(engine.checkGameOver()) {
					games = "Game Over! \n "+ "Your Score is: "+engine.calculateCasualties();
				    gameOverText.setText(games);
				    this.getContentPane().remove(mainPanel);
				    this.getContentPane().add(gameOverPanel);
				}
				engine.nextCycle();
			} catch (BuildingAlreadyCollapsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(this, e1.getMessage());
			} catch (CitizenAlreadyDeadException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		
		for (int i = 0; i < unitsArray.size(); i++) {
			if (e.getSource() == unitsArray.get(i)) {
				click = true;
				lastUclickedi = i;
			}
		}
		
		update();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
