package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Fire;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Address;
import simulation.Rescuable;

public class FireTruck extends FireUnit {

	public FireTruck(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		super(unitID, location, stepsPerCycle, worldListener);
	}

	@Override
	public void treat() {
		getTarget().getDisaster().setActive(false);

		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0) {
			jobsDone();
			return;
		} else if (target.getFireDamage() > 0)

			target.setFireDamage(target.getFireDamage() - 10);

		if (target.getFireDamage() == 0)

			jobsDone();

	}
	public void respond(Rescuable r) throws CannotTreatException, IncompatibleTargetException {
		if (r instanceof Citizen)
			throw new IncompatibleTargetException(this ,r," Sorry,Fire truck can not treat a Citizen ");
		
		else if (((ResidentialBuilding)r).getFireDamage()==0){
			throw new CannotTreatException (this,r,"Building is in safe state now ");
			
		}
		else if (r.getDisaster()!=null&& !(r.getDisaster()instanceof Fire) )
			throw new CannotTreatException(this,r,"Fire truck can only treat a fire");
		 if (r instanceof Citizen)
			throw new IncompatibleTargetException(this ,r," Sorry,Fire truck can not treat a Citizen ");
		else{
		if (getTarget() != null && ((ResidentialBuilding) getTarget()).getFireDamage()> 0
				&& getState() == UnitState.TREATING)
			reactivateDisaster();
		finishRespond(r);
	}
	}
}
