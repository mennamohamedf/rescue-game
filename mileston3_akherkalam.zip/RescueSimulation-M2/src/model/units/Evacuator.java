package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Collapse;
import model.disasters.Fire;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Address;
import simulation.Rescuable;

public class Evacuator extends PoliceUnit {

	public Evacuator(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener, int maxCapacity) {
		super(unitID, location, stepsPerCycle, worldListener, maxCapacity);

	}

	@Override
	public void treat() {
		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0
				|| target.getOccupants().size() == 0) {
			jobsDone();
			return;
		}

		for (int i = 0; getPassengers().size() != getMaxCapacity()
				&& i < target.getOccupants().size(); i++) {
			getPassengers().add(target.getOccupants().remove(i));
			i--;
		}

		setDistanceToBase(target.getLocation().getX()
				+ target.getLocation().getY());

	}

	public void respond(Rescuable r) throws CannotTreatException, IncompatibleTargetException {
		 if (r instanceof Citizen)
				throw new IncompatibleTargetException(this ,r," Sorry,Evacuator can not treat a Citizen ");
		 else if (((ResidentialBuilding)r).getFoundationDamage()==0){
			throw new CannotTreatException (this,r,"Building is in safe state now ");
			
		}
		else if (r.getDisaster()!=null&& !(r.getDisaster()instanceof Collapse) )
			throw new CannotTreatException(this,r,"evacuator can only treat a disaster of type collapse");
		
		else{
		
		
		
		if (getTarget() != null && ((Citizen) getTarget()).getBloodLoss() > 0
				&& getState() == UnitState.TREATING)
			reactivateDisaster();
		finishRespond(r);
	}
		

}
	 public String PassengersInfo() {
			String r = null;
			for(int i=0;i<getPassengers().size();i++) {
				 r= "Name: " + getPassengers().get(i).getName() + "\n ID" + getPassengers().get(i).getNationalID() + "\n Location:" + getPassengers().get(i).getLocation() + "\n Hp" + getPassengers().get(i).getHp() + "\n Bloodloss" + getPassengers().get(i).getBloodLoss() + "\n Toxicity" + getPassengers().get(i).getToxicity() + "\n State:" +getPassengers().get(i).getState() + "\n Age" + getPassengers().get(i).getAge();
			}
			return r;
		}
		public String toString() {
			String a= "number of passengers: " + this.getPassengers().size() + PassengersInfo();
		
		return a;}
}